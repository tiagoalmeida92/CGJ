#pragma once

int getIdx(int row, int column, int size);
void swap(float[], int, int);